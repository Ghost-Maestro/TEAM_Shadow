extends CharacterBody2D

# Contains the rat's battle stats and battle scene.
@export var enemy_data: Resource
# Identifies specfic overworld enemy beaten
@export var enemy_id: String = "rat_1"
@export var wander_distance: float = 30.0
@export var wander_speed: float = 25.0
@export var wander_wait_time: float = 2.5


# Prevents the enemy from starting the same encounter multiple times.
var encounter_triggered := false
var is_wandering: bool = false
# Stores the direction the rat is currently moving.
var wander_direction: Vector2 = Vector2.ZERO
# Tracks distance rat traveled during wander.
var distance_traveled: float = 0.0
var wander_timer: float = 0.0


# Runs enemies physics and controls wandering behavior.
# it can wait, wander, or battle
func _physics_process(delta):
	if encounter_triggered:
		velocity = Vector2.ZERO
		return
	if is_wandering:
		wander(delta)
	else:
		wait_to_wander(delta)


# timer to move again after moving
func wait_to_wander(delta):
	velocity = Vector2.ZERO
	wander_timer += delta

	if wander_timer >= wander_wait_time:
		wander_timer = 0.0
		choose_wander_direction()


# Randomized 8 direction movement
func choose_wander_direction():
	var directions = [
		Vector2.UP,
		Vector2.DOWN,
		Vector2.LEFT,
		Vector2.RIGHT,
		Vector2(1, 1).normalized(),
		Vector2(-1, 1).normalized(),
		Vector2(1, -1).normalized(),
		Vector2(-1, -1).normalized()
	]
	wander_direction = directions.pick_random()
	distance_traveled = 0.0
	is_wandering = true


# moves enemy in direction until its reached distance or hits a wall
func wander(_delta):
	velocity = wander_direction * wander_speed
	var previous_position = global_position
	move_and_slide()

	# stops wandering if hits wall
	if get_slide_collision_count() > 0:
		stop_wandering()
		return

	var movement_amount = global_position.distance_to(previous_position)
	distance_traveled += movement_amount
	if distance_traveled >= wander_distance:
		stop_wandering()


# Stops enemy and resets its wandering values so it can wait before moving again
func stop_wandering():
	velocity = Vector2.ZERO
	is_wandering = false
	distance_traveled = 0.0
	wander_timer = 0.0


# Detects when Player enters enemy area and starts battle
func _on_area_2d_body_entered(body):
	if body.is_in_group("player") and not encounter_triggered:
		encounter_triggered = true
		start_encounter()


# Creates encounter, randomly chooses 1-3 enemies, saves info needed to return after battle to enemy
func start_encounter():
	var enemy_count = randi_range(1, 3)
	var enemies = []

	# rats EnemyData saved to the battle list for every enemy
	for i in range(enemy_count):
		enemies.append(enemy_data)

	# saves orignal overworld rat that started battle id
	EncounterManager.current_overworld_enemy_id = enemy_id
	# saves orignal overworld rats position
	EncounterManager.current_overworld_enemy_position = global_position
	# Remembers which overworld scene the encounter started in.
	EncounterManager.previous_overworld_scene = get_tree().current_scene.scene_file_path
	# If the Player loses, returns 15 pixels to the left of the rat
	EncounterManager.overworld_return_position = Vector2(
		global_position.x - 275,
		global_position.y
	)
	EncounterManager.has_return_position = true
	print("battle started, overworld ID: ", enemy_id,", # of enemies: ", enemy_count)
	# sends enemy list through SignalBus
	SignalBus.encounter_started.emit(enemies)


# Runs when the overworld enemy first loads,If the rat was already defeated its removed
# setup for later if adding saves or respawning enemies or timers
func _ready():
	if EncounterManager.defeated_overworld_enemies.has(enemy_id):
		queue_free()
