extends Node

# Signals specfic data from monster resource to game
signal encounter_started(enemies)
