extends CharacterBody2D

@export var move_speed : float = 100.0

# custom actions defined, movement
func _physics_process(_delta: float) -> void:
	var input_direction = Input.get_vector("move_left", "move_right","move_up", "move_down")
	velocity = input_direction * move_speed
	move_and_slide()

# player position after battle on overworld
func _ready():
	if EncounterManager.has_return_position:
		global_position = EncounterManager.overworld_return_position
		print("Returned from battle, player position: ", global_position)
		EncounterManager.has_return_position = false
