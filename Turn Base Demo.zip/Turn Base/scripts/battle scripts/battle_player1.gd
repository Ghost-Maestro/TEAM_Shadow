extends CharacterBody2D

var player_name: String = "THRE-SHI"
var max_health: int = 30
var current_health: int = 30
var can_jump: bool = false
var is_jumping: bool = false
var ground_y: float
var jump_height: float = 40.0
var jump_duration: float = 0.9
@onready var name_label: Label = $HealthUI/NameLabel
@onready var health_bar: ProgressBar = $HealthUI/HealthBar


func _ready():
	ground_y = global_position.y
	setup_health_ui()
	
func enable_dodging():
	ground_y = global_position.y
	can_jump = true

func disable_dodging():
	can_jump = false
	
func setup_health_ui():
	name_label.text = player_name
	health_bar.min_value = 0
	health_bar.max_value = max_health
	health_bar.value = current_health
	print("Player name: ", player_name)
	print("Player HP: ", current_health, "/", max_health)
	print("Health bar value: ", health_bar.value)

func take_damage(amount: int):
	current_health -= amount
	if current_health < 0:
		current_health = 0
	health_bar.value = current_health

	print("Player took ", amount, " damage")
	print("Player HP: ", current_health, "/", max_health)
	if current_health <= 0:
		die()

func die():
	print("Player defeated!")
	get_tree().call_deferred(
		"change_scene_to_file",
		"res://scenes/world.tscn"
	)

func jump():
	if not can_jump:
		return
	if is_jumping:
		return
	is_jumping = true
	var start_y = global_position.y
	var tween = create_tween()

	# jump rise time, sent for battle
	tween.tween_property(
		self,
		"global_position:y",
		start_y - jump_height,
		jump_duration * 0.4
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

	# Small amount of hang time during jump
	tween.tween_interval(0.12)

	# jump fall time, sent for battle
	tween.tween_property(
		self,
		"global_position:y",
		start_y,
		jump_duration * 0.6
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	await tween.finished
	is_jumping = false
