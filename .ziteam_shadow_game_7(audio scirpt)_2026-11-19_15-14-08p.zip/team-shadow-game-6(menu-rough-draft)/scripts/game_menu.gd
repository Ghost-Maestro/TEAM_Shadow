extends CanvasLayer

@export var stats_texture: Texture2D
@export var items_texture: Texture2D
@export var map_texture: Texture2D

@onready var menu_ui = $MenuUI
@onready var stats_button = $MenuUI/HBoxContainer/LeftPanel/StatsButton
@onready var items_button = $MenuUI/HBoxContainer/LeftPanel/ItemsButton
@onready var map_button = $MenuUI/HBoxContainer/LeftPanel/MapButton
@onready var content_display = $MenuUI/HBoxContainer/RightPanel/ContentDisplay


# Prepare menu when scene loads
func _ready() -> void:
	# Allow menu inputs to work even when gameplay is paused
	process_mode = Node.PROCESS_MODE_ALWAYS
	menu_ui.hide()
	stats_button.pressed.connect(show_stats)
	items_button.pressed.connect(show_items)
	map_button.pressed.connect(show_map)
	show_stats()


# Detect M press
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("open_menu") and not event.is_echo():
		toggle_menu()
		get_viewport().set_input_as_handled()


# Open, close menu
func toggle_menu() -> void:
	if menu_ui.visible:
		close_menu()
	else:
		open_menu()


# Opens the menu and pauses gameplay
func open_menu() -> void:
	menu_ui.show()
	get_tree().paused = true
	show_stats()
	stats_button.grab_focus()
# Closes the menu and resumes gameplay
func close_menu() -> void:
	menu_ui.hide()
	get_tree().paused = false
	stats_button.release_focus()


# Display the Stats placeholder
func show_stats() -> void:
	content_display.texture = stats_texture
	print("Menu: Stats selected")
# Display the Items placeholder
func show_items() -> void:
	content_display.texture = items_texture
	print("Menu: Items selected")
# Display the Map placeholder
func show_map() -> void:
	content_display.texture = map_texture
	print("Menu: Map selected")
