extends Area2D

# Scene this teleporter leads to
@export_file("*.tscn") var next_scene: String
# side of the current forest this teleporter is on
@export_enum("Left", "Right", "Top", "Bottom") var exit_side: String = "Right"

static var pending_spawn_side: String = ""
var is_teleporting: bool = false


# Connects the teleporter when the scene loads
func _ready() -> void:
	body_entered.connect(_on_body_entered)
	call_deferred("_apply_pending_spawn")


# Detects the player entering a teleporter
func _on_body_entered(body: Node2D) -> void:
	if not body.is_in_group("player"):
		return
	is_teleporting = true
	# Determine which side of the next forest to spawn on
	match exit_side:
		"Left":
			pending_spawn_side = "Right"
		"Right":
			pending_spawn_side = "Left"
		"Top":
			pending_spawn_side = "Bottom"
		"Bottom":
			pending_spawn_side = "Top"
	SceneTransition.change_scene(next_scene)



func _apply_pending_spawn() -> void:
	if pending_spawn_side.is_empty():
		return
	await get_tree().process_frame
	var scene = get_tree().current_scene

	if scene == null:
		push_warning("Current scene not found.")
		return
	var marker_name = "Spawn" + pending_spawn_side
	var marker = scene.find_child(marker_name, true, false) as Marker2D
	
	if marker == null:
		push_error("Could not find marker: " + marker_name)
		return
	var player: Node2D = null
	for candidate in get_tree().get_nodes_in_group("player"):
		if candidate is Node2D and scene.is_ancestor_of(candidate):
			player = candidate
			break
	player.global_position = marker.global_position
	# Clear pending spawn information
	pending_spawn_side = ""
