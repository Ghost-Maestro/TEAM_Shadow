extends Node


# Called when the node enters the scene tree for the first time.
var Music_Player: AudioStreamPlayer = null

func _ready() -> void:
	Music_Player = AudioStreamPlayer.new()
	Music_Player.stream = load("res://s")
	Music_Player.autoplay = true
	add_child(Music_Player)


# Called every frame. 'delta' is the elapsed time since the previous frame.
