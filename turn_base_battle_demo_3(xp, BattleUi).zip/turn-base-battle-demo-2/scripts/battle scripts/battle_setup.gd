extends Node2D

@export var battle_player_scene: PackedScene
@onready var player_container = $PlayerContainer
@onready var player_position = $PlayerPosition
@onready var enemies_container = $Enemies
@onready var command_panel = $BattleUI/CommandPanel
@onready var enemy_positions = [
	$EnemyPosition/EnemyPosition1,
	$EnemyPosition/EnemyPosition2,
	$EnemyPosition/EnemyPosition3
]
# Stores which command Player currently has selected
# 0 = Attack, 1 = Run
var selected_command: int = 0
# Gets command labels from battle UI
@onready var attack_label: Label = $BattleUI/CommandPanel/VBoxContainer/AttackLabel
@onready var run_label: Label = $BattleUI/CommandPanel/VBoxContainer/RunLabel
# stores all enemies in battle
var battle_enemies: Array = []
# stores the BattlePlayer 
var player_instance
# begins with the Player's turn, then keeps track of the current turn
var battle_state: BattleState = BattleState.PLAYER_TURN
# Stores all XP earned during current battle
var battle_xp: int = 0

# control whether it is currently the Players or enemies turn
enum BattleState {
	PLAYER_TURN,
	ENEMY_TURN
}


# creates Player and all enemies needed for battle on load
func _ready():
	spawn_player()
	spawn_enemies()
	update_command_ui()


func spawn_player():
	if player_container == null:
		return
	if player_position == null:
		return
	if battle_player_scene == null:
		return

	# creates BattlePlayer
	player_instance = battle_player_scene.instantiate()
	# adds BattlePlayer to scene
	player_container.add_child(player_instance)
	player_instance.global_position = player_position.global_position



func spawn_enemies():
	# gets enemies that were selected in encounter manager when encounter started
	var enemies = EncounterManager.current_enemies
	if enemies_container == null:
		return
	# goes through every enemy that needs to be created
	for i in range(enemies.size()):
		# gets enemy's, EnemyData resource.
		var enemy_data = enemies[i]
		print(
			"Battle scene: ",
			enemy_data.battle_scene,
			". Using position: ",
			enemy_positions[i]
		)
		if enemy_positions[i] == null:
			print("ERROR: enemy position ", i, " not found")
			continue
		if enemy_data.battle_scene == null:
			print("ERROR: enemy does not have battle scene")
			continue

		# creates enemy's battle scene
		var enemy_instance = enemy_data.battle_scene.instantiate()
		# adds the enemy to battle
		enemies_container.add_child(enemy_instance)
		enemy_instance.global_position = enemy_positions[i].global_position
		# gives enemy its EnemyData 
		enemy_instance.setup(enemy_data)
		# adds the enemy to the list of active enemies
		battle_enemies.append(enemy_instance)


# handles Player input during battle, with arrows for menu and y selecting
# attacks during the Player's turn and jumps during the enemy turn
func _input(event):
	# PLAYER TURN
	if battle_state == BattleState.PLAYER_TURN:
		# Moves command selection up.
		if event.is_action_pressed("ui_up"):
			selected_command -= 1
			if selected_command < 0:
				selected_command = 1
			update_command_ui()
		# Moves the command selection down.
		elif event.is_action_pressed("ui_down"):
			selected_command += 1
			if selected_command > 1:
				selected_command = 0
			update_command_ui()
		# Y confirms the currently selected command.
		elif event.is_action_pressed("shi_y"):
			confirm_command()
	# ENEMY TURN
	elif battle_state == BattleState.ENEMY_TURN:
		# Space makes the Player jump during enemy attacks.
		if event.is_action_pressed("shi_y"):
			player_instance.jump()


func confirm_command():
	# Attack
	if selected_command == 0:
		battle_state = BattleState.ENEMY_TURN
		command_panel.hide()
		player_basic_attack()
	# Run
	elif selected_command == 1:
		run_from_battle()


# Updates command UI showing which option is selected
func update_command_ui():
	if selected_command == 0:
		attack_label.text = "> ATTACK"
		run_label.text = "  RUN"

	elif selected_command == 1:
		attack_label.text = "  ATTACK"
		run_label.text = "> RUN"


# Performs Player's basic two-strike, also checks for when a crit strikes activates
func player_basic_attack():
	# schedules enemy turn to begin after Player attack finishes
	call_deferred("start_enemy_turn")
	if battle_enemies.is_empty():
		return

	# the first enemy in list is treated as front enemy
	var front_enemy = battle_enemies[0]
	# randomly determines damage each strike deals
	var strike_one_roll = randi_range(2, 4)
	var strike_two_roll = randi_range(3, 6)
	
	# Gets Player 1's strength bonus based on lvl
	var strength = PartyManager.get_player1_strength()
	# adds strength modifer to end of attack without messing up CRIT
	var strike_one = strike_one_roll + strength
	var strike_two = strike_two_roll + strength

	print("----------------")
	print("PLAYER ATTACK!")
	print("Strike 1: ", strike_one)
	# First and second attack hits the front enemy 
	front_enemy.take_damage(strike_one)
	print("Strike 2: ", strike_two)
	front_enemy.take_damage(strike_two)

	# if both attacks roll maximum values, crit activates (not final product)
	if strike_one_roll == 4 and strike_two_roll == 6:
		print("CRITICAL ATTACK")
		critical_third_strike()
	call_deferred("clean_enemy_list")


# Performs the bonus third strike on crit, front enemy and enemy behind takes damage
func critical_third_strike():
	if battle_enemies.is_empty():
		return

	var front_enemy = battle_enemies[0]
	front_enemy.take_damage(9)
	if battle_enemies.size() > 1:
		var enemy_behind = battle_enemies[1]
		enemy_behind.take_damage(6)


# Running Option, leaves overworld as if lost
func run_from_battle():
	print("PLAYER RAN FROM BATTLE")

	get_tree().call_deferred(
		"change_scene_to_file",
		"res://scenes/world.tscn"
	)

# Removes enemies from list, keeps battle from interacting with deleted enemies
func clean_enemy_list():
	# duplicate() safely removes enemies while checking original list
	for enemy in battle_enemies.duplicate():
		# Removes enemies that no longer exist 
		if not is_instance_valid(enemy) or enemy.is_queued_for_deletion():
			battle_enemies.erase(enemy)


# controls the enemies' turn, each enemy attacks while the Player is allowed to jump.
func start_enemy_turn():
	# removes enemies defeated during Player's attack.
	clean_enemy_list()
	if battle_enemies.is_empty():
		battle_won()
		return
	print("----------------")
	print("ENEMY TURN")
	# allows Player to dodge during attack
	player_instance.enable_dodging()
	# gives short pause before enemies begin attacking
	await get_tree().create_timer(1.0).timeout

	# Goes through each enemy and waits for its attack to finish before the next enemies attack starts
	for enemy in battle_enemies.duplicate():
		if is_instance_valid(enemy):
			await enemy.perform_attack(player_instance, player_position)
	# Stops the Player from jumping once attacks finished
	player_instance.disable_dodging()
	clean_enemy_list()
	
	print("----------------")
	print("PLAYER TURN")
	command_panel.show()
	# gives control back to the Player
	battle_state = BattleState.PLAYER_TURN


# winning a battle, returns player in the spot of slain enemy
func battle_won():
	print("----------------")
	print("BATTLE WON")
	print("----------------")

	var total_xp: int = 0

# Adds up all EXP value of every enemy in battle
	for enemy_data in EncounterManager.current_enemies:
		total_xp += enemy_data.exp
	player_instance.gain_xp(total_xp)
	print("Battle XP earned: ", total_xp)

	# saves overworld enemy's ID as defeated so it does not respawn
	EncounterManager.mark_current_enemy_defeated()
	# Places the Player at position where enemy was defeated
	EncounterManager.overworld_return_position = \
		EncounterManager.current_overworld_enemy_position
	EncounterManager.has_return_position = true

	# changes from battle back to the overworld
	get_tree().call_deferred(
		"change_scene_to_file",
		"res://scenes/world.tscn"
	)
