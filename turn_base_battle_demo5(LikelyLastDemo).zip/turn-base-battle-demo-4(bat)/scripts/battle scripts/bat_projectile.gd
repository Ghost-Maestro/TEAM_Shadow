extends Area2D

# How long projectile takes to reach 
@export var travel_duration: float = 1.2
# Damage
var damage: int = 0
# Prevents projectile from damaging Player multiple times
var has_hit_player: bool = false


# Sends projectile towards fixed destination
func launch(target_position: Vector2, attack_damage: int):
	damage = attack_damage
	var tween = create_tween()

	tween.tween_property(
		self,
		"global_position",
		target_position,
		travel_duration
	).set_trans(Tween.TRANS_LINEAR)
	await tween.finished
	queue_free()


# Detects when projectile collides with Player
func _on_body_entered(body):
	if has_hit_player:
		return
	if body.is_in_group("player"):
		has_hit_player = true
		print("Bat projectile hit Player")
		body.take_damage(damage)
		queue_free()
