extends Node2D

@export var battle_player_scene: PackedScene
@onready var player_container = $PlayerContainer
@onready var player_position = $PlayerPosition
@onready var enemies_container = $Enemies
@onready var command_panel = $BattleUI/CommandPanel
@onready var enemy_positions = [
	$EnemyPosition/EnemyPosition1,
	$EnemyPosition/EnemyPosition2,
	$EnemyPosition/EnemyPosition3
]
# Stores which command Player currently has selected
# 0 = Attack, 1 = Run
var selected_command: int = 0
# Gets command labels from battle UI
@onready var attack_label: Label = $BattleUI/CommandPanel/VBoxContainer/AttackLabel
@onready var run_label: Label = $BattleUI/CommandPanel/VBoxContainer/RunLabel
# stores all enemies in battle
var battle_enemies: Array = []
# stores the BattlePlayer 
var player_instance
# begins with the Player's turn, then keeps track of the current turn
var battle_state: BattleState = BattleState.PLAYER_TURN
# Stores all XP earned during current battle
var battle_xp: int = 0
# Whether Player is currently selecting an enemy to attack
var is_selecting_target: bool = false
# The index of currently selected enemy
var selected_enemy_index: int = 0


# control whether it is currently the Players or enemies turn
enum BattleState {
	PLAYER_TURN,
	ENEMY_TURN
}


# creates Player and all enemies needed for battle on load
func _ready():
	spawn_player()
	spawn_enemies()
	update_command_ui()


func spawn_player():
	if player_container == null:
		return
	if player_position == null:
		return
	if battle_player_scene == null:
		return

	# creates BattlePlayer
	player_instance = battle_player_scene.instantiate()
	# adds BattlePlayer to scene
	player_container.add_child(player_instance)
	player_instance.global_position = player_position.global_position



func spawn_enemies():
	# gets enemies that were selected in encounter manager when encounter started
	var enemies = EncounterManager.current_enemies
	if enemies_container == null:
		return
	# goes through every enemy that needs to be created
	for i in range(enemies.size()):
		# gets enemy's, EnemyData resource.
		var enemy_data = enemies[i]
		print(
			"Battle scene: ",
			enemy_data.battle_scene,
			". Using position: ",
			enemy_positions[i]
		)
		if enemy_positions[i] == null:
			print("ERROR: enemy position ", i, " not found")
			continue
		if enemy_data.battle_scene == null:
			print("ERROR: enemy does not have battle scene")
			continue

# creates enemy's battle scene
		var enemy_instance = enemy_data.battle_scene.instantiate()
# adds enemy to battle
		enemies_container.add_child(enemy_instance)
# gets the enemy's ground position from its assigned marker
		var spawn_position = enemy_positions[i].global_position
# flying enemies spawn above their marker
		if enemy_data.is_flying:
			spawn_position.y -= enemy_data.flying_height
# places enemy at final position
		enemy_instance.global_position = spawn_position
# gives enemy its EnemyData 
		enemy_instance.setup(enemy_data)
# adds the enemy to the list of active enemies
		battle_enemies.append(enemy_instance)


# handles Player input during battle, with arrows for menu and y selecting
# attacks during the Player's turn and jumps during the enemy turn
# Handles command selection, enemy targeting, and jumping.
func _input(event):
	# PLAYER TURN
	if battle_state == BattleState.PLAYER_TURN:
		# TARGET SELECTION
		if is_selecting_target:
			if event.is_action_pressed("ui_left"):
				change_target(-1)
			elif event.is_action_pressed("ui_right"):
				change_target(1)
			elif event.is_action_pressed("shi_y"):
				confirm_command()
			elif event.is_action_pressed("ui_cancel"):
				stop_target_selection()
			return

		# COMMAND SELECTION
		if event.is_action_pressed("ui_up"):
			selected_command -= 1
			if selected_command < 0:
				selected_command = 1
			update_command_ui()
		elif event.is_action_pressed("ui_down"):
			selected_command += 1
			if selected_command > 1:
				selected_command = 0
			update_command_ui()
		elif event.is_action_pressed("shi_y"):
			confirm_command()

	# ENEMY TURN
	elif battle_state == BattleState.ENEMY_TURN:
		if event.is_action_pressed("shi_y"):
			player_instance.jump()


# executes the selected command or confirms the selected enemy
func confirm_command():
	# If already targeted, confirms the selected enemy
	if is_selecting_target:
		stop_target_selection()
		battle_state = BattleState.ENEMY_TURN
		command_panel.hide()
		player_basic_attack()
		return

	# Otherwise, handle the selected battle command
	if selected_command == 0:
		start_target_selection()
	elif selected_command == 1:
		run_from_battle()


# Updates command UI showing which option is selected
func update_command_ui():
	if selected_command == 0:
		attack_label.text = "> ATTACK"
		run_label.text = "  RUN"

	elif selected_command == 1:
		attack_label.text = "  ATTACK"
		run_label.text = "> RUN"


# Performs Player's basic two-strike, also checks for when a crit strikes activates
func player_basic_attack():
	# schedules enemy turn to begin after Player attack finishes
	call_deferred("start_enemy_turn")
	if battle_enemies.is_empty():
		return

	# gets enemy that the Player selected
	var front_enemy = battle_enemies[selected_enemy_index]
	# randomly determines damage each strike deals
	var strike_one_roll = randi_range(2, 4)
	var strike_two_roll = randi_range(3, 6)
	
	# Gets Player 1's strength bonus based on lvl
	var strength = PartyManager.get_player1_strength()
	# adds strength modifer to end of attack without messing up CRIT
	var strike_one = strike_one_roll + strength
	var strike_two = strike_two_roll + strength
	print("----------------")
	print("PLAYER ATTACK")
	print("Strike 1: ", strike_one)
	# First and second attack hits the front enemy 
	front_enemy.take_damage(strike_one)
	print("Strike 2: ", strike_two)
	front_enemy.take_damage(strike_two)

	# if both attacks roll maximum values, crit activates (not final product)
	if strike_one_roll == 4 and strike_two_roll == 6:
		print("CRITICAL ATTACK")
		critical_third_strike()
	call_deferred("clean_enemy_list")


# Performs a critical third strike on enemy and enemy behind it, if one exists
func critical_third_strike():
	if battle_enemies.is_empty():
		return
	# Deals bonus damage to the selected enemy
	var target_enemy = battle_enemies[selected_enemy_index]
	if is_instance_valid(target_enemy):
		target_enemy.take_damage(9)
	# Deals damage to the next enemy behind the selected target
	var behind_index = selected_enemy_index + 1
	if behind_index < battle_enemies.size():
		var enemy_behind = battle_enemies[behind_index]
		if is_instance_valid(enemy_behind):
			enemy_behind.take_damage(6)


# Running Option, leaves overworld as if lost
func run_from_battle():
	print("PLAYER RAN FROM BATTLE")

	get_tree().call_deferred(
		"change_scene_to_file",
		"res://scenes/world.tscn"
	)


# target selection and highlights first living enemy
func start_target_selection():
	clean_enemy_list()
	if battle_enemies.is_empty():
		return
	is_selecting_target = true
	selected_enemy_index = 0
	update_target_highlight()


# updates which enemy is blinking
func update_target_highlight():
	for i in range(battle_enemies.size()):
		var enemy = battle_enemies[i]
		if is_instance_valid(enemy):
			enemy.set_targeted(i == selected_enemy_index)


# stops targeting and restores enemy sprites
func stop_target_selection():
	is_selecting_target = false
	for enemy in battle_enemies:
		if is_instance_valid(enemy):
			enemy.set_targeted(false)


# Changes selected target using the Left/Right arrows
func change_target(direction: int):
	if battle_enemies.is_empty():
		return
	selected_enemy_index += direction
	# wraps around from the last enemy to the first and vice versa
	if selected_enemy_index < 0:
		selected_enemy_index = battle_enemies.size() - 1
	elif selected_enemy_index >= battle_enemies.size():
		selected_enemy_index = 0
	update_target_highlight()


# Removes enemies from list, keeps battle from interacting with deleted enemies
func clean_enemy_list():
	# duplicate() safely removes enemies while checking original list
	for enemy in battle_enemies.duplicate():
		# Removes enemies that no longer exist 
		if not is_instance_valid(enemy) or enemy.is_queued_for_deletion():
			battle_enemies.erase(enemy)


# controls the enemies' turn, each enemy attacks while the Player is allowed to jump
func start_enemy_turn():
	# removes enemies defeated during Player's attack.
	clean_enemy_list()
	if battle_enemies.is_empty():
		battle_won()
		return
	print("----------------")
	print("ENEMY TURN")
	# allows Player to dodge during attack
	player_instance.enable_dodging()
	# gives short pause before enemies begin attacking
	await get_tree().create_timer(1.0).timeout

	# Goes through each enemy and waits for its attack to finish before the next enemies attack starts
	for enemy in battle_enemies.duplicate():
		if is_instance_valid(enemy):
			await enemy.perform_attack(player_instance, player_position)
	# Stops the Player from jumping once attacks finished
	player_instance.disable_dodging()
	clean_enemy_list()
	
	print("----------------")
	print("PLAYER TURN")
	command_panel.show()
	# gives control back to the Player
	battle_state = BattleState.PLAYER_TURN


# winning a battle, returns player in the spot of slain enemy
func battle_won():
	print("----------------")
	print("BATTLE WON")
	print("----------------")

	var total_xp: int = 0

# Adds up all EXP value of every enemy in battle
	for enemy_data in EncounterManager.current_enemies:
		total_xp += enemy_data.get_exp_reward()
	player_instance.gain_xp(total_xp)
	print("Battle XP earned: ", total_xp)

	# saves overworld enemy's ID as defeated so it does not respawn
	EncounterManager.mark_current_enemy_defeated()
	# Places the Player at position where enemy was defeated
	EncounterManager.overworld_return_position = \
		EncounterManager.current_overworld_enemy_position
	EncounterManager.has_return_position = true

	# changes from battle back to the overworld
	get_tree().call_deferred(
		"change_scene_to_file",
		"res://scenes/world.tscn"
	)
