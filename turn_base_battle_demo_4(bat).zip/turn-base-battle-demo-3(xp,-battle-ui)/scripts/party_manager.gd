extends Node

# Player 1 permanent lvl progression.
var player1_level: int = 1
var player1_xp: int = 0
var player1_next_level_xp: int = 10


# Gives XP to player 1
func give_player1_xp(amount: int):
	player1_xp += amount
	print("Player 1 gained ", amount, " XP")
	print("XP: ", player1_xp, "/", player1_next_level_xp)
	check_player1_level_up()


# Checks if player 1 earned enough XP to level up
func check_player1_level_up():
	while player1_xp >= player1_next_level_xp:
		player1_xp -= player1_next_level_xp
		player1_level += 1
		player1_next_level_xp += 10
		print("PLAYER 1 LEVEL UP, ", player1_level)


# Player 1's maximum health 
func get_player1_max_health() -> int:
	return 5 + (25 * player1_level)

# Player 1's bonus attack damage 
func get_player1_strength() -> int:
	return 4 * player1_level
