extends Resource
class_name EnemyData

# grabs data from resource data
@export var name : String =  "Monster"
@export var texture : Texture2D
@export var health : int 
@export var damage : int
@export var exp: int 
@export var battle_scene: PackedScene
